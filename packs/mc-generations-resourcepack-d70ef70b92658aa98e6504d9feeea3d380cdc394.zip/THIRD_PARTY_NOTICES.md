# Third-party notices

## Flow lava text effect

The `Flow lava` branch in `assets/minecraft/shaders/core/text.fsh` adapts the flow-noise structure from:

- **Noise animation - Lava**
- Author: nimitz (`@stormoid`)
- Source: https://www.shadertoy.com/view/lslXRS
- License: Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported
- License text: https://creativecommons.org/licenses/by-nc-sa/3.0/

Changes made for MC-Generations include replacing ShaderToy's `iChannel0` texture noise with smooth procedural
gradient noise, using Minecraft's `GameTime` and text-fragment coordinates, rotating successive octave domains to
avoid lattice artifacts, and band-limiting the domain growth for small text and icon glyphs.
