# Third-party notices

## Flow lava text effect

The `Flow lava` branch in `assets/minecraft/shaders/core/text.fsh` adapts the flow-noise structure from:

- **Noise animation - Lava**
- Author: nimitz (`@stormoid`)
- Source: https://www.shadertoy.com/view/lslXRS
- License: Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported
- License text: https://creativecommons.org/licenses/by-nc-sa/3.0/

Changes made for MC-Generations include replacing ShaderToy's `iChannel0` texture noise with smooth procedural
gradient noise, using Minecraft's `GameTime` and text-fragment coordinates, rotating successive octave domains to
avoid lattice artifacts, and band-limiting the domain growth for small text and icon glyphs.

## Turbulent water text effect

The `Turbulent water` branch in `assets/minecraft/shaders/core/text.fsh` adapts shader code supplied with this
attribution:

- Tiling adaptation: David Hoskins
- Original water-turbulence effect: joltz0r
- Described by its header as found on GLSL Sandbox

No canonical source URL or explicit license accompanied the supplied shader, and a canonical publication could
not be confirmed. The attribution is retained here; redistribution rights should be confirmed with the authors.

Changes made for MC-Generations include using Minecraft's `GameTime`, mapping screen coordinates into a 96-pixel
repeating text-space tile, and guarding trigonometric divisors against zero.
