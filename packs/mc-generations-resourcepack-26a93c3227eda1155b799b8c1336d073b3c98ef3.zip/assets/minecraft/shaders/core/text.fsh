#version 330

// Marker-font animation experiment inspired by JavierFlores09's technique:
// https://gist.github.com/JavierFlores09/55b59b7176cf0789546a50171d382b76

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in float sphericalVertexDistance;
in float cylindricalVertexDistance;
#endif

in vec4 vertexColor;
in vec2 texCoord0;

out vec4 fragColor;

vec3 hsvToRgb(vec3 hsv) {
    vec3 p = abs(fract(hsv.xxx + vec3(0.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0);
    return hsv.z * mix(vec3(1.0), clamp(p - 1.0, 0.0, 1.0), hsv.y);
}

void main() {
#ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
#else
    vec4 texColor = texture(Sampler0, texCoord0);
#endif

    bool replaceTextColor = false;

#if !defined(IS_GRAYSCALE)
    ivec3 metadata = ivec3(round(texColor.rgb * 255.0));
    bool isAnimatedRainbow = metadata == ivec3(52, 50, 253);
    bool isAnimatedFire = metadata == ivec3(55, 40, 253);
    bool isAnimatedWater = metadata == ivec3(56, 60, 253);

    if (isAnimatedRainbow) {
        float gameTicks = GameTime * 24000.0;
        float hue = fract(0.2 - gameTicks / 50.0 + gl_FragCoord.x / 160.0);
        texColor.rgb = hsvToRgb(vec3(hue, 0.75, 0.75));
        replaceTextColor = true;
    } else if (isAnimatedFire) {
        float gameTicks = GameTime * 24000.0;
        float drift = sin(gl_FragCoord.x * 0.21 - gameTicks * 0.16);
        float flicker = 0.5 + 0.5 * sin(gl_FragCoord.x * 0.73 - gameTicks * 0.47 + drift);
        float tongue = pow(0.5 + 0.5 * sin(gl_FragCoord.x * 1.37 - gameTicks * 0.81), 6.0);
        vec3 ember = vec3(0.72, 0.025, 0.0);
        vec3 flame = vec3(1.0, 0.28, 0.0);
        vec3 hot = vec3(1.0, 0.88, 0.16);
        texColor.rgb = mix(mix(ember, flame, flicker), hot, tongue * 0.85);
        replaceTextColor = true;
    } else if (isAnimatedWater) {
        float gameTicks = GameTime * 24000.0;
        float current = sin(gl_FragCoord.y * 0.22 + gameTicks * 0.08) * 0.35;
        float wave = 0.5 + 0.5 * sin(gl_FragCoord.x * 0.16 - gameTicks * 0.14 + current);
        float caustic = pow(0.5 + 0.5 * sin(gl_FragCoord.x * 0.31 + gameTicks * 0.09 - current), 8.0);
        vec3 deep = vec3(0.015, 0.16, 0.58);
        vec3 surface = vec3(0.02, 0.62, 0.95);
        vec3 foam = vec3(0.45, 0.92, 1.0);
        texColor.rgb = mix(mix(deep, surface, wave), foam, caustic * 0.65);
        replaceTextColor = true;
    }
#endif

    float vertexBrightness = max(max(vertexColor.r, vertexColor.g), vertexColor.b);
    vec4 appliedVertexColor = replaceTextColor
        ? vec4(vec3(vertexBrightness), vertexColor.a)
        : vertexColor;

#ifdef IS_SEE_THROUGH
    vec4 color = texColor * appliedVertexColor;
#else
    vec4 color = texColor * appliedVertexColor * ColorModulator;
#endif
    if (color.a < 0.1) {
        discard;
    }

#ifdef IS_SEE_THROUGH
    fragColor = color * ColorModulator;
#elif defined(IS_GUI)
    fragColor = color;
#else
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
#endif
}
