#version 330

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#endif

out vec4 vertexColor;
out vec2 texCoord0;
flat out int textEffect;
flat out float effectStartTick;
flat out int fadeTone;
out float effectDistance;
out float effectLetterPosition;

const float TAU = 6.28318530718;

float hash11(float value) {
    return fract(sin(value * 127.1) * 43758.5453);
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    ivec3 colorMetadata = ivec3(round(Color.rgb * 255.0));
    bool standardMarker = colorMetadata.r == 200 && colorMetadata.b == 252;
    bool timedMarker = colorMetadata.r >= 201 && colorMetadata.r <= 205;
    bool chatFadeMarker = colorMetadata.r >= 206 && colorMetadata.r <= 212;
    bool staggeredChatFadeMarker = colorMetadata.r >= 213 && colorMetadata.r <= 219;
    textEffect = standardMarker
        ? colorMetadata.g
        : (timedMarker
            ? 39 + colorMetadata.r - 201
            : (chatFadeMarker ? 39 : (staggeredChatFadeMarker ? 44 : 0)));
    effectStartTick = timedMarker || chatFadeMarker || staggeredChatFadeMarker
        ? float(colorMetadata.g * 256 + colorMetadata.b)
        : 0.0;
    fadeTone = chatFadeMarker
        ? colorMetadata.r - 206
        : (staggeredChatFadeMarker ? colorMetadata.r - 213 : -1);
    effectDistance = 0.0;
    effectLetterPosition = Position.x / 6.0;

    float gameTicks = GameTime * 24000.0;
    float glyphIndex = floor(Position.x / 6.0);
    vec2 displacementPixels = vec2(0.0);

    if (textEffect == 24) {
        displacementPixels.y = abs(sin(gameTicks * 0.19 + glyphIndex * 0.83)) * 3.2;
    } else if (textEffect == 25) {
        displacementPixels.y = sin(gameTicks * 0.13 + Position.x * 0.28) * 2.7;
    } else if (textEffect == 26) {
        float burst = fract(gameTicks / 70.0);
        float angle = hash11(glyphIndex + 19.0) * TAU;
        float distance = burst * burst * 13.0;
        displacementPixels = vec2(cos(angle), sin(angle)) * distance;
    } else if (textEffect == 29) {
        float ghostBounce = abs(sin(gameTicks * 0.12 + glyphIndex * 1.07));
        float ghostDrift = sin(gameTicks * 0.055 + glyphIndex * 0.61);
        displacementPixels = vec2(ghostDrift * 0.45, ghostBounce * 2.2);
    }

    vec2 pixelToClip = 2.0 / max(ScreenSize, vec2(1.0));
    gl_Position.xy += displacementPixels * pixelToClip * gl_Position.w;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    effectDistance = sphericalVertexDistance;
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;
}
