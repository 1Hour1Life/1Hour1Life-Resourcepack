#version 330

// Marker-font animation system inspired by JavierFlores09's technique:
// https://gist.github.com/JavierFlores09/55b59b7176cf0789546a50171d382b76

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in float sphericalVertexDistance;
in float cylindricalVertexDistance;
#endif

in vec4 vertexColor;
in vec2 texCoord0;
flat in int textEffect;
in float effectDistance;

out vec4 fragColor;

const float TAU = 6.28318530718;

vec3 hsvToRgb(vec3 hsv) {
    vec3 p = abs(fract(hsv.xxx + vec3(0.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0);
    return hsv.z * mix(vec3(1.0), clamp(p - 1.0, 0.0, 1.0), hsv.y);
}

float hash11(float value) {
    return fract(sin(value * 127.1) * 43758.5453);
}

float hash12(vec2 value) {
    vec3 p3 = fract(vec3(value.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float glyphAlpha(vec2 pixelOffset) {
    vec2 texturePixels = vec2(textureSize(Sampler0, 0));
    return texture(Sampler0, texCoord0 + pixelOffset / texturePixels).a;
}

void main() {
#ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
#else
    vec4 texColor = texture(Sampler0, texCoord0);
#endif

    int effectId = textEffect;
#if !defined(IS_GRAYSCALE)
    if (effectId == 0) {
        ivec3 metadata = ivec3(round(texColor.rgb * 255.0));
        if (metadata == ivec3(52, 50, 253)) {
            effectId = 1;
        } else if (metadata == ivec3(55, 40, 253)) {
            effectId = 2;
        } else if (metadata == ivec3(56, 60, 253)) {
            effectId = 3;
        }
    }
#endif

    float gameTicks = GameTime * 24000.0;
    vec2 pixel = gl_FragCoord.xy;
    float effectAlpha = 1.0;

    switch (effectId) {
        case 1: {
            float hue = fract(0.2 - gameTicks / 50.0 + pixel.x / 160.0);
            texColor.rgb = hsvToRgb(vec3(hue, 0.75, 0.75));
            break;
        }
        case 2: {
            float drift = sin(pixel.x * 0.21 - gameTicks * 0.16);
            float flicker = 0.5 + 0.5 * sin(pixel.x * 0.73 - gameTicks * 0.47 + drift);
            float tongue = pow(0.5 + 0.5 * sin(pixel.x * 1.37 - gameTicks * 0.81), 6.0);
            vec3 ember = vec3(0.72, 0.025, 0.0);
            vec3 flame = vec3(1.0, 0.28, 0.0);
            vec3 hot = vec3(1.0, 0.88, 0.16);
            texColor.rgb = mix(mix(ember, flame, flicker), hot, tongue * 0.85);
            break;
        }
        case 3: {
            float current = sin(pixel.y * 0.22 + gameTicks * 0.08) * 0.35;
            float wave = 0.5 + 0.5 * sin(pixel.x * 0.16 - gameTicks * 0.14 + current);
            float caustic = pow(0.5 + 0.5 * sin(pixel.x * 0.31 + gameTicks * 0.09 - current), 8.0);
            texColor.rgb = mix(
                mix(vec3(0.015, 0.16, 0.58), vec3(0.02, 0.62, 0.95), wave),
                vec3(0.45, 0.92, 1.0),
                caustic * 0.65
            );
            break;
        }
        case 4: {
            float sweep = pow(0.5 + 0.5 * cos(pixel.x * 0.12 - gameTicks * 0.16), 18.0);
            texColor.rgb = mix(vec3(0.55, 0.25, 0.015), vec3(1.0, 0.91, 0.38), 0.35 + 0.65 * sweep);
            break;
        }
        case 5: {
            float crystal = pow(0.5 + 0.5 * sin(pixel.x * 0.42 + pixel.y * 0.31 - gameTicks * 0.05), 12.0);
            float frost = 0.5 + 0.5 * sin(pixel.y * 0.35 + gameTicks * 0.035);
            texColor.rgb = mix(vec3(0.08, 0.32, 0.72), vec3(0.72, 0.96, 1.0), frost * 0.55 + crystal * 0.45);
            break;
        }
        case 6: {
            float arc = pow(abs(sin(pixel.x * 0.53 + pixel.y * 0.23 - gameTicks * 0.65)), 18.0);
            float flash = step(0.94, hash11(floor(gameTicks / 3.0) + floor(pixel.x / 8.0)));
            texColor.rgb = mix(vec3(0.015, 0.28, 0.75), vec3(0.78, 1.0, 1.0), max(arc, flash));
            break;
        }
        case 7: {
            float bubble = 0.5 + 0.5 * sin(pixel.x * 0.31 - gameTicks * 0.12 + sin(pixel.y * 0.4));
            float pop = pow(0.5 + 0.5 * sin(pixel.y * 0.67 + gameTicks * 0.24), 10.0);
            texColor.rgb = mix(vec3(0.20, 0.03, 0.34), vec3(0.35, 0.95, 0.08), clamp(bubble + pop * 0.35, 0.0, 1.0));
            break;
        }
        case 8: {
            float voidWave = 0.5 + 0.5 * sin(pixel.x * 0.11 + pixel.y * 0.17 - gameTicks * 0.07);
            float mote = step(0.975, hash12(floor(pixel / 2.0) + floor(gameTicks / 5.0)));
            texColor.rgb = mix(vec3(0.005, 0.0, 0.02), vec3(0.28, 0.02, 0.52), voidWave * 0.65) + mote * vec3(0.65, 0.28, 1.0);
            break;
        }
        case 9: {
            float molten = 0.5 + 0.5 * sin(pixel.x * 0.13 + sin(pixel.y * 0.19) - gameTicks * 0.055);
            float crack = pow(abs(sin(pixel.x * 0.29 - pixel.y * 0.16 + gameTicks * 0.04)), 24.0);
            texColor.rgb = mix(vec3(0.18, 0.008, 0.0), vec3(0.95, 0.16, 0.0), molten) + crack * vec3(0.9, 0.62, 0.08);
            break;
        }
        case 10: {
            float band = sin(pixel.x * 0.045 + pixel.y * 0.08 - gameTicks * 0.045 + sin(pixel.x * 0.015));
            float hue = 0.42 + 0.28 * (0.5 + 0.5 * band);
            texColor.rgb = hsvToRgb(vec3(hue, 0.72, 0.78));
            break;
        }
        case 11: {
            float reflection = pow(abs(sin(pixel.x * 0.10 - gameTicks * 0.08)), 7.0);
            float fineBand = pow(abs(sin(pixel.x * 0.31 + gameTicks * 0.04)), 24.0);
            texColor.rgb = vec3(0.12 + reflection * 0.72 + fineBand * 0.28);
            break;
        }
        case 12: {
            float breath = 0.58 + 0.34 * (0.5 + 0.5 * cos(TAU * gameTicks / 80.0));
            texColor.rgb = mix(vec3(0.16, 0.42, 0.82), vec3(0.62, 0.88, 1.0), breath);
            break;
        }
        case 13: {
            float sparkle = step(0.965, hash12(floor(pixel) + floor(gameTicks / 2.0)));
            float trail = pow(0.5 + 0.5 * sin(pixel.x * 0.18 - gameTicks * 0.18), 14.0);
            texColor.rgb = mix(vec3(0.30, 0.09, 0.58), vec3(1.0, 0.88, 1.0), max(sparkle, trail * 0.7));
            break;
        }
        case 14: {
            float line = pow(0.5 + 0.5 * sin(pixel.y * 1.55 - gameTicks * 0.34), 9.0);
            texColor.rgb = mix(vec3(0.015, 0.22, 0.25), vec3(0.18, 1.0, 0.78), line);
            break;
        }
        case 15: {
            float cycle = 0.18 + 0.62 * (0.5 + 0.5 * sin(TAU * gameTicks / 110.0));
            float grain = hash12(floor(pixel) + floor(gameTicks / 8.0));
            effectAlpha *= smoothstep(cycle - 0.08, cycle + 0.08, grain);
            texColor.rgb = mix(vec3(0.32, 0.05, 0.46), vec3(0.95, 0.35, 1.0), grain);
            break;
        }
        case 16: {
            float alert = 0.5 + 0.5 * sin(TAU * gameTicks / 20.0);
            texColor.rgb = mix(vec3(0.55, 0.0, 0.0), vec3(1.0, 0.42, 0.0), alert);
            break;
        }
        case 17: {
            float flow = 0.5 + 0.5 * sin(pixel.x * 0.055 - gameTicks * 0.06);
            vec3 redToGold = mix(vec3(0.82, 0.04, 0.08), vec3(1.0, 0.72, 0.08), smoothstep(0.0, 0.5, flow));
            texColor.rgb = mix(redToGold, vec3(0.08, 0.32, 0.92), smoothstep(0.5, 1.0, flow));
            break;
        }
        case 18: {
            texColor.rgb = vec3(0.38, 0.82, 1.0);
            effectAlpha *= effectDistance > 0.001
                ? 1.0 - smoothstep(8.0, 28.0, effectDistance)
                : 0.62 + 0.30 * (0.5 + 0.5 * sin(TAU * gameTicks / 70.0));
            break;
        }
        case 19: {
            float bandSeed = hash11(floor(pixel.y / 3.0) + floor(gameTicks / 3.0));
            float jump = step(0.78, bandSeed) * (bandSeed - 0.5) * 7.0;
            texColor.a = glyphAlpha(vec2(jump, 0.0));
            float split = step(0.90, hash11(floor(gameTicks / 2.0) + floor(pixel.x / 5.0)));
            texColor.rgb = mix(vec3(0.04, 0.86, 0.95), vec3(1.0, 0.03, 0.42), split);
            break;
        }
        case 20: {
            vec2 ripple = vec2(
                sin(pixel.y * 0.55 + gameTicks * 0.14),
                cos(pixel.x * 0.38 - gameTicks * 0.11)
            ) * 1.35;
            texColor.a = glyphAlpha(ripple);
            float sheen = 0.5 + 0.5 * sin(pixel.x * 0.14 + pixel.y * 0.08 - gameTicks * 0.12);
            texColor.rgb = mix(vec3(0.02, 0.28, 0.62), vec3(0.38, 0.94, 1.0), sheen);
            break;
        }
        case 21: {
            float phase = 0.5 + 0.5 * sin(TAU * gameTicks / 95.0 + pixel.x * 0.09);
            float drip = phase * phase * 3.0;
            texColor.a = glyphAlpha(vec2(0.0, -drip));
            float gap = hash12(vec2(floor(pixel.x / 2.0), floor(gameTicks / 7.0)));
            effectAlpha *= smoothstep(0.12, 0.32, gap + phase * 0.25);
            texColor.rgb = mix(vec3(0.48, 0.015, 0.24), vec3(1.0, 0.30, 0.08), phase);
            break;
        }
        case 22: {
            float reveal = fract(gameTicks / 90.0);
            float localX = fract(pixel.x / 128.0);
            effectAlpha *= step(localX, reveal);
            float caret = 1.0 - smoothstep(0.0, 0.025, abs(localX - reveal));
            texColor.rgb = mix(vec3(0.08, 0.68, 0.34), vec3(0.78, 1.0, 0.82), caret);
            break;
        }
        case 23: {
            float base = texColor.a;
            float neighbor = 0.0;
            neighbor = max(neighbor, glyphAlpha(vec2(1.0, 0.0)));
            neighbor = max(neighbor, glyphAlpha(vec2(-1.0, 0.0)));
            neighbor = max(neighbor, glyphAlpha(vec2(0.0, 1.0)));
            neighbor = max(neighbor, glyphAlpha(vec2(0.0, -1.0)));
            neighbor = max(neighbor, glyphAlpha(vec2(1.0, 1.0)));
            neighbor = max(neighbor, glyphAlpha(vec2(-1.0, 1.0)));
            neighbor = max(neighbor, glyphAlpha(vec2(1.0, -1.0)));
            neighbor = max(neighbor, glyphAlpha(vec2(-1.0, -1.0)));
            texColor.a = max(base, neighbor * 0.72);
            float pulse = 0.75 + 0.25 * sin(TAU * gameTicks / 55.0);
            texColor.rgb = mix(vec3(0.02, 0.48, 0.82) * pulse, vec3(0.82, 1.0, 1.0), base);
            break;
        }
        case 24: {
            float shine = 0.5 + 0.5 * sin(pixel.x * 0.16 - gameTicks * 0.13);
            texColor.rgb = mix(vec3(0.18, 0.46, 0.95), vec3(1.0, 0.82, 0.24), shine);
            break;
        }
        case 25: {
            float hue = 0.35 + 0.22 * (0.5 + 0.5 * sin(pixel.x * 0.07 - gameTicks * 0.07));
            texColor.rgb = hsvToRgb(vec3(hue, 0.68, 0.82));
            break;
        }
        case 26: {
            float burst = fract(gameTicks / 70.0);
            effectAlpha *= 1.0 - smoothstep(0.38, 0.88, burst);
            texColor.rgb = mix(vec3(1.0, 0.18, 0.02), vec3(1.0, 0.92, 0.24), 1.0 - burst);
            break;
        }
        default:
            break;
    }

    texColor.a *= effectAlpha;
    bool replaceTextColor = effectId > 0;
    float vertexBrightness = max(max(vertexColor.r, vertexColor.g), vertexColor.b);
    vec4 appliedVertexColor = replaceTextColor
        ? vec4(vec3(vertexBrightness), vertexColor.a)
        : vertexColor;

#ifdef IS_SEE_THROUGH
    vec4 color = texColor * appliedVertexColor;
#else
    vec4 color = texColor * appliedVertexColor * ColorModulator;
#endif
    if (color.a < 0.1) {
        discard;
    }

#ifdef IS_SEE_THROUGH
    fragColor = color * ColorModulator;
#elif defined(IS_GUI)
    fragColor = color;
#else
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
#endif
}
