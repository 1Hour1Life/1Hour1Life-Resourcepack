#version 330

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in float sphericalVertexDistance;
in float cylindricalVertexDistance;
#endif

in vec4 vertexColor;
in vec2 texCoord0;
flat in int textEffect;
flat in float effectStartTick;
in float effectDistance;
in float effectLetterPosition;

out vec4 fragColor;

const float TAU = 6.28318530718;

vec3 hsvToRgb(vec3 hsv) {
    vec3 p = abs(fract(hsv.xxx + vec3(0.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0);
    return hsv.z * mix(vec3(1.0), clamp(p - 1.0, 0.0, 1.0), hsv.y);
}

float hash11(float value) {
    return fract(sin(value * 127.1) * 43758.5453);
}

float hash12(vec2 value) {
    vec3 p3 = fract(vec3(value.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

mat2 rotate2d(float theta) {
    float cosine = cos(theta);
    float sine = sin(theta);
    return mat2(cosine, -sine, sine, cosine);
}

vec2 randomGradient(vec2 cell) {
    vec2 gradient = vec2(
        hash12(cell) * 2.0 - 1.0,
        hash12(cell + vec2(19.19, 73.73)) * 2.0 - 1.0
    );
    return normalize(gradient + vec2(0.0001));
}

float gradientNoise(vec2 point) {
    vec2 cell = floor(point);
    vec2 local = fract(point);
    vec2 blend = local * local * local * (local * (local * 6.0 - 15.0) + 10.0);
    float bottomLeft = dot(randomGradient(cell), local);
    float bottomRight = dot(randomGradient(cell + vec2(1.0, 0.0)), local - vec2(1.0, 0.0));
    float topLeft = dot(randomGradient(cell + vec2(0.0, 1.0)), local - vec2(0.0, 1.0));
    float topRight = dot(randomGradient(cell + vec2(1.0, 1.0)), local - vec2(1.0, 1.0));
    float bottom = mix(bottomLeft, bottomRight, blend.x);
    float top = mix(topLeft, topRight, blend.x);
    return clamp(0.5 + 0.75 * mix(bottom, top, blend.y), 0.0, 1.0);
}

// Rotating every octave prevents the interpolation lattice from lining up into
// screen-space rows or diagonals. Use this for effects meant to look organic.
float organicField(vec2 pixel, float fieldTime, float scale) {
    vec2 point = pixel * scale + vec2(fieldTime * 0.37, -fieldTime * 0.23);
    mat2 octaveRotation = rotate2d(0.71);
    float amplitude = 0.56;
    float result = 0.0;
    float weight = 0.0;

    for (int octave = 0; octave < 4; octave++) {
        result += gradientNoise(point) * amplitude;
        weight += amplitude;
        point = octaveRotation * point * 1.82 + vec2(13.1, 7.7);
        amplitude *= 0.5;
    }
    return result / weight;
}

vec2 noiseGradient(vec2 point) {
    const float epsilon = 0.09;
    float gradientX = gradientNoise(point + vec2(epsilon, 0.0))
        - gradientNoise(point - vec2(epsilon, 0.0));
    float gradientY = gradientNoise(point + vec2(0.0, epsilon))
        - gradientNoise(point - vec2(0.0, epsilon));
    return vec2(gradientX, gradientY);
}

float flowLava(vec2 point, float flowTime) {
    float intensityScale = 2.0;
    float result = 0.0;
    vec2 basePoint = point;

    for (int octave = 1; octave < 7; octave++) {
        point += vec2(0.52, 0.21) * flowTime;
        basePoint += vec2(-0.17, 0.63) * flowTime;

        vec2 displacement = noiseGradient(float(octave) * point * 0.34 + vec2(flowTime));
        float rotation = flowTime * 6.0 - (0.05 * point.x + 0.03 * point.y) * 40.0;
        displacement = rotate2d(rotation) * displacement;
        point += displacement * 0.5;

        result += (sin(gradientNoise(point * 0.55) * 7.0) * 0.5 + 0.5) / intensityScale;
        point = mix(basePoint, point, 0.77);
        intensityScale *= 1.4;
        point = rotate2d(0.58) * point * 1.75;
        basePoint = rotate2d(-0.41) * basePoint * 1.68;
    }
    return result;
}

float safeWave(float value) {
    return value < 0.0 ? min(value, -0.0001) : max(value, 0.0001);
}

vec3 turbulentWater(vec2 pixel, float gameTicks) {
    float waterTime = gameTicks / 40.0 + 23.0;
    vec2 uv = fract(pixel / 96.0);
    vec2 point = mod(uv * TAU, TAU) - 250.0;
    vec2 iterationPoint = point;
    float turbulence = 1.0;
    const float intensity = 0.005;

    for (int iteration = 0; iteration < 5; iteration++) {
        float iterationTime = waterTime * (1.0 - 3.5 / float(iteration + 1));
        iterationPoint = point + vec2(
            cos(iterationTime - iterationPoint.x) + sin(iterationTime + iterationPoint.y),
            sin(iterationTime - iterationPoint.y) + cos(iterationTime + iterationPoint.x)
        );
        vec2 divisor = vec2(
            point.x * intensity / safeWave(sin(iterationPoint.x + iterationTime)),
            point.y * intensity / safeWave(cos(iterationPoint.y + iterationTime))
        );
        turbulence += 1.0 / max(length(divisor), 0.0001);
    }

    turbulence /= 5.0;
    turbulence = 1.17 - pow(turbulence, 1.4);
    vec3 caustic = vec3(pow(abs(turbulence), 8.0));
    return clamp(caustic + vec3(0.0, 0.35, 0.5), 0.0, 1.0);
}

float glyphAlpha(vec2 pixelOffset) {
    vec2 texturePixels = vec2(textureSize(Sampler0, 0));
    return texture(Sampler0, texCoord0 + pixelOffset / texturePixels).a;
}

void main() {
#ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
#else
    vec4 texColor = texture(Sampler0, texCoord0);
#endif

    int effectId = textEffect;
#if !defined(IS_GRAYSCALE)
    if (effectId == 0) {
        ivec3 metadata = ivec3(round(texColor.rgb * 255.0));
        if (metadata == ivec3(52, 50, 253)) {
            effectId = 1;
        } else if (metadata == ivec3(55, 40, 253)) {
            effectId = 2;
        } else if (metadata == ivec3(56, 60, 253)) {
            effectId = 3;
        }
    }
#endif

    float gameTicks = GameTime * 24000.0;
    float effectTicks = mod(gameTicks - effectStartTick + 24000.0, 24000.0);
    vec2 pixel = gl_FragCoord.xy;
    float effectAlpha = 1.0;

    switch (effectId) {
        case 1: {
            // Deliberate broad horizontal color travel, not a texture artifact.
            float hue = fract(0.2 - gameTicks / 50.0 + pixel.x / 160.0);
            texColor.rgb = hsvToRgb(vec3(hue, 0.75, 0.75));
            break;
        }
        case 2: {
            vec2 risingPixel = pixel + vec2(sin(gameTicks * 0.11) * 3.5, -gameTicks * 1.35);
            float turbulence = organicField(risingPixel, gameTicks * 0.08, 0.045);
            vec2 warpedPixel = risingPixel + vec2((turbulence - 0.5) * 18.0, 0.0);
            float flameBody = organicField(warpedPixel, -gameTicks * 0.12, 0.065);
            float flameDetail = organicField(
                rotate2d(0.48) * warpedPixel + vec2(37.0, -19.0),
                gameTicks * 0.24,
                0.075
            );
            float flicker = smoothstep(0.32, 0.68, flameBody * 0.72 + flameDetail * 0.38);
            float flare = 0.72 + 0.28 * sin(TAU * gameTicks / 13.0);
            float tongue = smoothstep(0.56, 0.72, flameDetail + (turbulence - 0.5) * 0.30) * flare;
            vec3 ember = vec3(0.72, 0.025, 0.0);
            vec3 flame = vec3(1.0, 0.28, 0.0);
            vec3 hot = vec3(1.0, 0.88, 0.16);
            texColor.rgb = mix(mix(ember, flame, flicker), hot, tongue * 0.85);
            break;
        }
        case 3: {
            float current = organicField(pixel, gameTicks * 0.055, 0.035);
            float wave = organicField(pixel + vec2(current * 18.0, 0.0), gameTicks * 0.075, 0.045);
            float caustic = pow(organicField(pixel + vec2(31.0, 17.0), -gameTicks * 0.09, 0.075), 7.0);
            texColor.rgb = mix(
                mix(vec3(0.025, 0.20, 0.68), vec3(0.02, 0.72, 1.0), smoothstep(0.30, 0.70, wave)),
                vec3(0.72, 0.98, 1.0),
                caustic * 0.88
            );
            break;
        }
        case 4: {
            // Sparse diagonal highlight adapted from the supplied cubic sine shimmer.
            // The long text-space period keeps most labels to a single visible sweep.
            float shimmerPhase = (pixel.y + pixel.x * 3.0) * 0.028 - gameTicks * 0.45;
            float shimmer = sin(shimmerPhase) * 0.9;
            shimmer *= shimmer * shimmer * 0.6;
            shimmer = clamp(shimmer, 0.0, 1.0);
            vec3 gold = mix(vec3(0.55, 0.25, 0.015), vec3(1.0, 0.78, 0.20), 0.38);
            texColor.rgb = clamp(gold + vec3(shimmer), 0.0, 1.0);
            break;
        }
        case 5: {
            float crystal = smoothstep(0.58, 0.70, organicField(pixel + vec2(-23.0, 41.0), gameTicks * 0.045, 0.08));
            float frost = organicField(pixel, -gameTicks * 0.025, 0.04);
            texColor.rgb = mix(vec3(0.08, 0.32, 0.72), vec3(0.72, 0.96, 1.0), frost * 0.55 + crystal * 0.45);
            break;
        }
        case 6: {
            float charge = organicField(pixel, gameTicks * 0.42, 0.075);
            float arc = smoothstep(0.59, 0.70, charge);
            float flash = step(0.94, hash11(floor(gameTicks / 3.0) + floor(pixel.x / 8.0)));
            texColor.rgb = mix(vec3(0.015, 0.28, 0.75), vec3(0.78, 1.0, 1.0), max(arc, flash));
            break;
        }
        case 7: {
            float bubble = organicField(pixel, gameTicks * 0.08, 0.052);
            float pop = pow(organicField(pixel + vec2(47.0, 11.0), -gameTicks * 0.17, 0.08), 8.0);
            texColor.rgb = mix(vec3(0.20, 0.03, 0.34), vec3(0.35, 0.95, 0.08), clamp(bubble + pop * 0.35, 0.0, 1.0));
            break;
        }
        case 8: {
            float voidWave = organicField(pixel, gameTicks * 0.045, 0.035);
            float mote = step(0.975, hash12(floor(pixel / 2.0) + floor(gameTicks / 5.0)));
            texColor.rgb = mix(vec3(0.005, 0.0, 0.02), vec3(0.28, 0.02, 0.52), voidWave * 0.65) + mote * vec3(0.65, 0.28, 1.0);
            break;
        }
        case 9: {
            float molten = organicField(pixel, gameTicks * 0.055, 0.04);
            float crackField = organicField(pixel + vec2(61.0, -29.0), -gameTicks * 0.035, 0.075);
            float crack = smoothstep(0.60, 0.72, crackField);
            texColor.rgb = mix(vec3(0.18, 0.008, 0.0), vec3(0.95, 0.16, 0.0), molten) + crack * vec3(0.9, 0.62, 0.08);
            break;
        }
        case 10: {
            // Aurora has intentional bands, but noise bends them so they never become straight diagonals.
            float warp = organicField(pixel, gameTicks * 0.02, 0.025);
            float band = sin(pixel.y * 0.075 - gameTicks * 0.045 + warp * 3.2);
            float hue = 0.42 + 0.28 * (0.5 + 0.5 * band);
            texColor.rgb = hsvToRgb(vec3(hue, 0.72, 0.78));
            break;
        }
        case 12: {
            float breath = 0.5 + 0.5 * cos(TAU * gameTicks / 72.0);
            texColor.rgb = mix(vec3(0.055, 0.16, 0.52), vec3(0.76, 0.96, 1.0), smoothstep(0.08, 0.92, breath));
            break;
        }
        case 13: {
            float sparkle = step(0.965, hash12(floor(pixel) + floor(gameTicks / 2.0)));
            float bloom = smoothstep(0.61, 0.73, organicField(pixel, gameTicks * 0.15, 0.08));
            texColor.rgb = mix(vec3(0.30, 0.09, 0.58), vec3(1.0, 0.88, 1.0), max(sparkle, bloom * 0.7));
            break;
        }
        case 14: {
            // Deliberate CRT scanlines.
            float line = pow(0.5 + 0.5 * sin(pixel.y * 1.55 - gameTicks * 0.34), 9.0);
            texColor.rgb = mix(vec3(0.015, 0.22, 0.25), vec3(0.18, 1.0, 0.78), line);
            break;
        }
        case 15: {
            float cycle = 0.18 + 0.62 * (0.5 + 0.5 * sin(TAU * gameTicks / 110.0));
            float grain = hash12(floor(pixel) + floor(gameTicks / 8.0));
            effectAlpha *= smoothstep(cycle - 0.08, cycle + 0.08, grain);
            texColor.rgb = mix(vec3(0.32, 0.05, 0.46), vec3(0.95, 0.35, 1.0), grain);
            break;
        }
        case 16: {
            float alert = 0.5 + 0.5 * sin(TAU * gameTicks / 20.0);
            texColor.rgb = mix(vec3(0.55, 0.0, 0.0), vec3(1.0, 0.42, 0.0), alert);
            break;
        }
        case 17: {
            float flow = organicField(pixel, gameTicks * 0.035, 0.022);
            vec3 redToGold = mix(vec3(0.82, 0.04, 0.08), vec3(1.0, 0.72, 0.08), smoothstep(0.0, 0.5, flow));
            texColor.rgb = mix(redToGold, vec3(0.08, 0.32, 0.92), smoothstep(0.5, 1.0, flow));
            break;
        }
        case 18: {
            texColor.rgb = vec3(0.38, 0.82, 1.0);
            effectAlpha *= effectDistance > 0.001
                ? 1.0 - smoothstep(8.0, 28.0, effectDistance)
                : 0.62 + 0.30 * (0.5 + 0.5 * sin(TAU * gameTicks / 70.0));
            break;
        }
        case 19: {
            // Deliberate horizontal glitch bands and channel jumps.
            float bandSeed = hash11(floor(pixel.y / 3.0) + floor(gameTicks / 3.0));
            float jump = step(0.78, bandSeed) * (bandSeed - 0.5) * 7.0;
            texColor.a = glyphAlpha(vec2(jump, 0.0));
            float split = step(0.90, hash11(floor(gameTicks / 2.0) + floor(pixel.x / 5.0)));
            texColor.rgb = mix(vec3(0.01, 0.95, 0.20), vec3(0.68, 0.06, 1.0), split);
            break;
        }
        case 20: {
            float baseAlpha = texColor.a;
            vec2 ripple = noiseGradient(pixel * 0.055 + vec2(gameTicks * 0.035, -gameTicks * 0.025)) * 3.2;
            texColor.a = mix(baseAlpha, glyphAlpha(ripple), 0.38);
            float sheen = organicField(pixel + vec2(17.0, 43.0), gameTicks * 0.08, 0.05);
            texColor.rgb = mix(vec3(0.02, 0.28, 0.62), vec3(0.38, 0.94, 1.0), sheen);
            break;
        }
        case 21: {
            float phase = organicField(pixel, gameTicks * 0.05, 0.035);
            float drip = phase * phase * 3.0;
            texColor.a = glyphAlpha(vec2(0.0, -drip));
            float gap = hash12(vec2(floor(pixel.x / 2.0), floor(gameTicks / 7.0)));
            effectAlpha *= smoothstep(0.12, 0.32, gap + phase * 0.25);
            texColor.rgb = mix(vec3(0.48, 0.015, 0.24), vec3(1.0, 0.30, 0.08), phase);
            break;
        }
        case 22: {
            float reveal = fract(gameTicks / 90.0);
            float localX = fract(pixel.x / 128.0);
            effectAlpha *= step(localX, reveal);
            float caret = 1.0 - smoothstep(0.0, 0.025, abs(localX - reveal));
            texColor.rgb = mix(vec3(0.08, 0.68, 0.34), vec3(0.78, 1.0, 0.82), caret);
            break;
        }
        case 23: {
            float base = texColor.a;
            float neighbor = 0.0;
            neighbor = max(neighbor, glyphAlpha(vec2(1.0, 0.0)));
            neighbor = max(neighbor, glyphAlpha(vec2(-1.0, 0.0)));
            neighbor = max(neighbor, glyphAlpha(vec2(0.0, 1.0)));
            neighbor = max(neighbor, glyphAlpha(vec2(0.0, -1.0)));
            neighbor = max(neighbor, glyphAlpha(vec2(1.0, 1.0)));
            neighbor = max(neighbor, glyphAlpha(vec2(-1.0, 1.0)));
            neighbor = max(neighbor, glyphAlpha(vec2(1.0, -1.0)));
            neighbor = max(neighbor, glyphAlpha(vec2(-1.0, -1.0)));
            texColor.a = max(base, neighbor * 0.72);
            float pulse = 0.75 + 0.25 * sin(TAU * gameTicks / 55.0);
            texColor.rgb = mix(vec3(0.02, 0.48, 0.82) * pulse, vec3(0.82, 1.0, 1.0), base);
            break;
        }
        case 24: {
            float shine = organicField(pixel, gameTicks * 0.10, 0.045);
            texColor.rgb = mix(vec3(0.18, 0.46, 0.95), vec3(1.0, 0.82, 0.24), shine);
            break;
        }
        case 25: {
            float hue = 0.35 + 0.22 * organicField(pixel, gameTicks * 0.055, 0.025);
            texColor.rgb = hsvToRgb(vec3(hue, 0.68, 0.82));
            break;
        }
        case 26: {
            float burst = fract(gameTicks / 70.0);
            effectAlpha *= 1.0 - smoothstep(0.38, 0.88, burst);
            texColor.rgb = mix(vec3(1.0, 0.18, 0.02), vec3(1.0, 0.92, 0.24), 1.0 - burst);
            break;
        }
        case 27: {
            vec2 lavaPoint = pixel * 0.022;
            float flowTime = gameTicks / 10.0;
            float ridgedFlow = max(flowLava(lavaPoint, flowTime), 0.055);
            vec3 moltenColor = vec3(0.2, 0.07, 0.01) / ridgedFlow;
            texColor.rgb = pow(moltenColor, vec3(1.4));
            break;
        }
        case 28: {
            texColor.rgb = turbulentWater(pixel, gameTicks);
            break;
        }
        case 29: {
            // Atlas-space grain remains attached to each glyph while its vertices bounce.
            vec2 atlasPixel = floor(texCoord0 * vec2(textureSize(Sampler0, 0)));
            float dissolveGrain = hash12(atlasPixel);
            effectAlpha *= smoothstep(0.14, 0.30, dissolveGrain) * 0.82;
            float spirit = organicField(pixel, gameTicks * 0.045, 0.035);
            texColor.rgb = mix(vec3(0.30, 0.62, 0.70), vec3(0.78, 0.94, 1.0), spirit);
            break;
        }
        case 30: {
            float letterIndex = floor(effectLetterPosition);
            float faultWindow = floor(gameTicks / 14.0);
            float faultSeed = hash12(vec2(letterIndex + 31.0, faultWindow + 79.0));
            float faultyLetter = step(0.87, faultSeed);
            float blinkStep = floor(gameTicks / 1.75);
            float blinkSeed = hash12(vec2(letterIndex + 113.0, blinkStep));
            float switchedOff = faultyLetter * step(0.43, blinkSeed);
            float electricHum = 0.92 + 0.08 * sin(TAU * gameTicks / 9.0 + letterIndex * 1.7);
            effectAlpha *= mix(1.0, 0.045, switchedOff);
            texColor.rgb = mix(vec3(1.0, 0.55, 0.08), vec3(1.0, 0.96, 0.72), electricHum);
            break;
        }
        case 31: {
            float nebula = organicField(pixel + vec2(9.0, -31.0), gameTicks * 0.018, 0.026);
            float deepCloud = organicField(rotate2d(0.63) * pixel, -gameTicks * 0.012, 0.014);
            vec2 nearStarCell = floor((pixel + vec2(gameTicks * 0.11, -gameTicks * 0.04)) / 3.0);
            vec2 farStarCell = floor((pixel + vec2(-gameTicks * 0.035, gameTicks * 0.018)) / 5.0);
            float nearStar = step(0.945, hash12(nearStarCell));
            float farStar = step(0.91, hash12(farStarCell + vec2(71.0, 19.0))) * 0.52;
            float twinkle = 0.72 + 0.28 * sin(gameTicks * 0.21 + hash12(nearStarCell) * TAU);
            vec3 portalColor = mix(vec3(0.045, 0.008, 0.12), vec3(0.48, 0.08, 0.78), nebula);
            portalColor = mix(portalColor, vec3(0.10, 0.30, 0.52), deepCloud * 0.32);
            texColor.rgb = clamp(portalColor + (nearStar * twinkle + farStar) * vec3(0.72, 0.88, 1.0), 0.0, 1.0);
            break;
        }
        case 32: {
            vec2 crystalSpace = rotate2d(0.42) * pixel / 6.0;
            vec2 facetCell = floor(crystalSpace);
            vec2 facetLocal = fract(crystalSpace);
            float diagonal = step(facetLocal.y, facetLocal.x);
            float facetSeed = hash12(facetCell + vec2(diagonal * 17.0));
            float hue = fract(facetSeed * 0.72 + gameTicks / 210.0 + pixel.x / 420.0);
            float facetLight = 0.70 + 0.26 * hash12(facetCell + vec2(43.0, 89.0));
            float crystalEdge = smoothstep(0.72, 0.96, max(abs(facetLocal.x - facetLocal.y), abs(facetLocal.x + facetLocal.y - 1.0)));
            texColor.rgb = mix(hsvToRgb(vec3(hue, 0.62, facetLight)), vec3(0.92, 0.98, 1.0), crystalEdge * 0.42);
            break;
        }
        case 33: {
            vec2 risingPixel = pixel + vec2(sin(gameTicks * 0.08) * 2.0, -gameTicks * 0.92);
            float spiritBody = organicField(risingPixel, gameTicks * 0.055, 0.052);
            float spiritTongue = smoothstep(0.56, 0.72, organicField(
                rotate2d(-0.37) * risingPixel + vec2(29.0, 13.0),
                -gameTicks * 0.11,
                0.078
            ));
            float ghostPulse = 0.78 + 0.22 * sin(TAU * gameTicks / 19.0);
            texColor.rgb = mix(vec3(0.005, 0.20, 0.25), vec3(0.02, 0.76, 0.72), spiritBody);
            texColor.rgb = mix(texColor.rgb, vec3(0.72, 1.0, 0.88), spiritTongue * ghostPulse);
            break;
        }
        case 34: {
            float projectionLine = pow(0.5 + 0.5 * sin(pixel.y * 2.15 - gameTicks * 0.42), 12.0);
            float interference = step(0.91, hash11(floor(pixel.y / 2.0) + floor(gameTicks / 2.5)));
            float signal = 0.82 + 0.18 * sin(gameTicks * 0.16 + pixel.x * 0.055);
            vec3 hologramBase = mix(vec3(0.015, 0.38, 0.62), vec3(0.16, 1.0, 0.94), projectionLine);
            texColor.rgb = mix(hologramBase * signal, vec3(0.72, 0.16, 1.0), interference * 0.72);
            effectAlpha *= mix(1.0, 0.68, interference);
            break;
        }
        case 35: {
            float quartzBody = organicField(pixel + vec2(13.0, 47.0), gameTicks * 0.018, 0.030);
            float veinField = organicField(rotate2d(0.91) * pixel, -gameTicks * 0.025, 0.085);
            float vein = smoothstep(0.47, 0.54, veinField) * (1.0 - smoothstep(0.54, 0.61, veinField));
            float gleam = pow(max(0.0, sin((pixel.x + pixel.y * 0.42) * 0.045 - gameTicks * 0.13)), 18.0);
            vec3 quartz = mix(vec3(0.42, 0.07, 0.22), vec3(0.96, 0.38, 0.62), quartzBody);
            texColor.rgb = mix(quartz, vec3(1.0, 0.82, 0.91), clamp(vein * 0.75 + gleam, 0.0, 1.0));
            break;
        }
        case 36: {
            float shadow = organicField(pixel, gameTicks * 0.012, 0.021);
            float coronaPhase = pixel.x * 0.055 + pixel.y * 0.018 - gameTicks * 0.075 + shadow * 2.4;
            float corona = pow(abs(sin(coronaPhase)), 13.0);
            float emberDust = step(0.968, hash12(floor(pixel / 2.0) + floor(gameTicks / 7.0)));
            vec3 eclipsed = mix(vec3(0.075, 0.004, 0.012), vec3(0.48, 0.025, 0.018), shadow);
            texColor.rgb = clamp(eclipsed + corona * vec3(1.0, 0.56, 0.08) + emberDust * vec3(0.72, 0.18, 0.02), 0.0, 1.0);
            break;
        }
        case 37: {
            float portalWarp = organicField(pixel + vec2(0.0, -gameTicks * 0.48), gameTicks * 0.035, 0.038);
            float portalRibbon = 0.5 + 0.5 * sin(
                pixel.y * 0.22 - gameTicks * 0.28 + portalWarp * 7.5 + sin(pixel.x * 0.075) * 1.8
            );
            float portalDepth = organicField(
                rotate2d(-0.28) * pixel + vec2(37.0, gameTicks * 0.31),
                -gameTicks * 0.026,
                0.062
            );
            float portalSpark = step(
                0.962,
                hash12(floor(pixel / 2.0) + vec2(floor(gameTicks / 3.0), floor(-gameTicks / 5.0)))
            );
            vec3 portalBase = mix(vec3(0.12, 0.005, 0.30), vec3(0.48, 0.035, 0.82), portalDepth);
            vec3 portalGlow = mix(vec3(0.62, 0.08, 1.0), vec3(1.0, 0.24, 0.88), portalRibbon);
            texColor.rgb = mix(portalBase, portalGlow, smoothstep(0.40, 0.82, portalRibbon) * 0.72);
            texColor.rgb = clamp(texColor.rgb + portalSpark * vec3(0.82, 0.42, 1.0), 0.0, 1.0);
            break;
        }
        case 38: {
            // The original glitch motion with the reference's dominant yellow and red signal split.
            float cyberBandSeed = hash11(floor(pixel.y / 3.0) + floor(gameTicks / 3.0));
            float cyberJump = step(0.78, cyberBandSeed) * (cyberBandSeed - 0.5) * 7.0;
            texColor.a = glyphAlpha(vec2(cyberJump, 0.0));
            float redSplit = step(0.90, hash11(floor(gameTicks / 2.0) + floor(pixel.x / 5.0)));
            texColor.rgb = mix(vec3(1.0, 0.94, 0.0), vec3(0.94, 0.015, 0.055), redSplit);
            break;
        }
        case 39: {
            float fade = smoothstep(0.0, 12.0, effectTicks);
            effectAlpha *= fade;
            texColor.rgb = vec3(0.92, 0.95, 1.0);
            break;
        }
        case 40: {
            float fade = smoothstep(0.0, 8.0, effectTicks);
            float active = 1.0 - smoothstep(34.0, 52.0, effectTicks);
            float sweepPhase = (pixel.y + pixel.x * 2.6) * 0.030 - effectTicks * 0.31;
            float shimmer = pow(max(0.0, sin(sweepPhase)), 14.0) * active;
            texColor.rgb = mix(vec3(0.92, 0.58, 0.08), vec3(1.0, 0.96, 0.68), shimmer);
            effectAlpha *= fade;
            break;
        }
        case 41: {
            float fade = smoothstep(0.0, 8.0, effectTicks);
            float progress = clamp((effectTicks - 4.0) / 34.0, 0.0, 1.0);
            float glow = sin(progress * 3.14159265) * step(effectTicks, 38.0);
            texColor.rgb = mix(vec3(0.38, 0.76, 0.88), vec3(0.86, 1.0, 1.0), glow * 0.62);
            effectAlpha *= fade;
            break;
        }
        case 42: {
            float fade = smoothstep(0.0, 6.0, effectTicks);
            float active = 1.0 - smoothstep(42.0, 55.0, effectTicks);
            float pulse = pow(0.5 + 0.5 * sin(TAU * effectTicks / 15.0), 2.0) * active;
            texColor.rgb = mix(vec3(0.96, 0.57, 0.08), vec3(1.0, 0.91, 0.48), pulse * 0.72);
            effectAlpha *= fade;
            break;
        }
        case 43: {
            float fade = smoothstep(0.0, 8.0, effectTicks);
            float active = 1.0 - smoothstep(35.0, 50.0, effectTicks);
            vec2 sparkleCell = floor(pixel / 2.0);
            float sparkle = step(0.93, hash12(sparkleCell + floor(effectTicks / 3.0))) * active;
            float glintPhase = (pixel.x + pixel.y * 0.35) * 0.055 - effectTicks * 0.24;
            float glint = pow(max(0.0, sin(glintPhase)), 18.0) * active;
            texColor.rgb = mix(vec3(0.38, 0.86, 0.58), vec3(0.94, 1.0, 0.78), max(sparkle, glint));
            effectAlpha *= fade;
            break;
        }
        default:
            break;
    }

    texColor.a *= effectAlpha;
    bool replaceTextColor = effectId > 0;
    float vertexBrightness = effectId >= 39
        ? 1.0
        : max(max(vertexColor.r, vertexColor.g), vertexColor.b);
    vec4 appliedVertexColor = replaceTextColor
        ? vec4(vec3(vertexBrightness), vertexColor.a)
        : vertexColor;

#ifdef IS_SEE_THROUGH
    vec4 color = texColor * appliedVertexColor;
#else
    vec4 color = texColor * appliedVertexColor * ColorModulator;
#endif
    if (color.a < 0.1) {
        discard;
    }

#ifdef IS_SEE_THROUGH
    fragColor = color * ColorModulator;
#elif defined(IS_GUI)
    fragColor = color;
#else
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
#endif
}
